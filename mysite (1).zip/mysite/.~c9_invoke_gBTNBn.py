from flask import Flask, render_template, request, session
from cs50 import SQL
from tempfile import mkdtemp
from flask_session import Session

app = Flask(__name__)

db = SQL("sqlite:///dbname.db")
# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/more")
def more():
    return render_template("more.html")

@app.route("/support")
def support():
    return render_template("support.html")

@app.route("/work")
def work():
    return render_template("work.html")
@app.route("/q1")
@app.route("/q1")
def q1():
    session.clear()
    db.execute('insert into work values (NULL, 0)')
    last = db.execute('select max(id) as id from work')
    session["user_id"] = last[0]['id']
    return render_template("q1.html")

@app.route("/q2")
def q2():
    answer = request.args.get('answer')
    if answer == '2':
        db.execute('update work set points = points + 1 where id = :id', id=session["user_id"])
    return render_template("q2.html")

@app.route("/q3")
def q3():
    answer = request.args.get('answer')
    if answer == '2':
        db.execute('update work set points = points + 1 where id = :id', id=session["user_id"])
    return render_template("q3.html")

@app.route("/q4")
def q4():

    answer = request.args.get('answer')
    if answer == '2':
        db.execute('update work set points = points + 1 where id = :id', id=session["user_id"])
    return render_template("q4.html")

@app.route("/q5")
def q5():
    answer = request.args.get('answer')
    if answer == 'yes':
        db.execute('update work set points = points + 1 where id = :id', id=session["user_id"])

    return render_template("q5.html")

@app.route("/q6")
def q6():
    answer = request.args.get('answer')
    if answer == 'yes':
        db.execute('update work set points = points + 1 where id = :id', id=session["user_id"])

    return render_template("q6.html")

@app.route("/q7")
def q7():
    answer = request.args.get('answer')
    if answer == 'yes':
        db.execute('update work set points = points + 1 where id = :id', id=session["user_id"])

    return render_template("q7.html")

@app.route("/q8")
def q8():
    answer = request.args.get('answer')
    if answer == 'yes':
        db.execute('update work set points = points + 1 where id = :id', id=session["user_id"])

    return render_template("q8.html")

@app.route("/q9")
def q9():
    answer = request.args.get('answer')
    if answer == 'yes':
        db.execute('update work set points = points + 1 where id = :id', id=session["user_id"])

    return render_template("q9.html")

@app.route("/q10")
def q10():
    answer = request.args.get('answer')
    if answer == 'yes':
        db.execute('update work set points = points + 1 where id = :id', id=session["user_id"])

    return render_template("q10.html")

@app.route("/result")
def result():
    answer = request.args.get('answer')
    if answer == 'yes':
        db.execute('update work set points = points + 1 where id = :id', id=session["user_id"])
    total_points = db.execute('select points from work where id = :id', id=session["user_id"])
    return render_template("result.html", total_points = total_points[0]['points'])

@app.route("/jobs")
def jobs():

    return render_template("jobs.html")
